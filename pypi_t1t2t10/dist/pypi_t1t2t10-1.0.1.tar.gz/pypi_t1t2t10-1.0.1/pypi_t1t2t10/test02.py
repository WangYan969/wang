# coding:utf-8
# 引入同级目录模块
# import test22 as t1
# t1.ceshi("sdsad")

# =============
# 引入这个模块的全部
# from test22 import *
# ceshi("sdasd")
# s1 = stu('ssssssss')
# s1.say()

# 引入非同级目录模块
# from test23 import test03 as t3
# t3.ceshi("asd")

# from test23.test03 import stu
# s1 = stu("ss")
# s1.say()